<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
require_once '../includes/layout.php';

$products = $conn->query('SELECT id, product_name, category, quantity, price FROM products ORDER BY id DESC');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Inventory System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php render_sidebar(); ?>
        <main class="main-panel">
            <?php render_topbar(); ?>
            <section class="content">
                <div class="page-heading">
                    <div>
                        <p class="eyebrow">Products</p>
                        <h1>All inventory items</h1>
                    </div>
                    <a class="btn btn-primary" href="create.php">Add product</a>
                </div>
                <div class="table-wrap">
                    <?php if ($products && $products->num_rows > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($product = $products->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                                        <td>
                                            <span class="stock-badge <?php echo ((int) $product['quantity'] <= 10) ? 'stock-low' : 'stock-ok'; ?>">
                                                <?php echo (int) $product['quantity']; ?> in stock
                                            </span>
                                        </td>
                                        <td>$<?php echo number_format((float) $product['price'], 2); ?></td>
                                        <td class="action-cell">
                                            <div class="action-menu">
                                                <button class="btn btn-primary" type="button" onclick="toggleActionMenu(<?php echo (int) $product['id']; ?>)">Action</button>
                                                <div id="actionMenu<?php echo (int) $product['id']; ?>" class="action-dropdown">
                                                    <a href="edit.php?id=<?php echo (int) $product['id']; ?>">Edit</a>
                                                    <a href="delete.php?id=<?php echo (int) $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <strong>No products found.</strong>
                            <p>Add products so they appear in this list.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
