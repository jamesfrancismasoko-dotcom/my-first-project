<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
require_once '../includes/layout.php';

$id = (int) ($_GET['id'] ?? 0);

if ($id > 0) {
    $stmt = $conn->prepare('DELETE FROM products WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php');
    exit();
}

$products = $conn->query('SELECT id, product_name, category, quantity, price FROM products ORDER BY id DESC');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product - Inventory System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php render_sidebar(); ?>
        <main class="main-panel">
            <?php render_topbar(); ?>
            <section class="content">
                <div class="page-heading">
                    <div>
                        <p class="eyebrow">Products</p>
                        <h1>Delete products</h1>
                    </div>
                    <a class="btn btn-secondary" href="index.php">Back to list</a>
                </div>
                <div class="notice">
                    Choose Delete only for items that should be removed from the inventory records.
                </div>
                <div class="table-wrap">
                    <?php if ($products && $products->num_rows > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($product = $products->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                                        <td><?php echo (int) $product['quantity']; ?> in stock</td>
                                        <td>$<?php echo number_format((float) $product['price'], 2); ?></td>
                                        <td>
                                            <a class="btn btn-danger" href="delete.php?id=<?php echo (int) $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <strong>No products found.</strong>
                            <p>There are no products available to delete.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
