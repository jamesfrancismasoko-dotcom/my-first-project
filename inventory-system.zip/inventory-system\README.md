# Inventory System

A complete PHP and MySQL inventory system for tracking products, stock quantities, prices, and low-stock items.

## Requirements

- PHP 7.4 or later
- MySQL or MariaDB
- Apache server such as XAMPP, WAMP, or Laragon

## Installation

1. Copy the `inventory-system` folder into your web server root directory.
   - XAMPP example: `C:\xampp\htdocs\inventory-system`

2. Start Apache and MySQL.

3. Open phpMyAdmin and import `database/inventory_db.sql`.
   - The script creates the `inventory_db` database.
   - It also creates the `users` and `products` tables with sample records.

4. Confirm the database settings in `config/db.php`.

```php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'inventory_db';
```

5. Open the project in your browser.

```text
http://localhost/inventory-system/
```

## Default Login

```text
Email: admin@example.com
Password: password
```

You can also create a new user from the Register page.

## Features

- User registration with `password_hash()`
- User login with `password_verify()`
- Session-protected dashboard and product pages
- Dashboard summary for total products, stock quantity, stock value, and low-stock products
- Add, view, edit, and delete products
- Responsive layout with clearer desktop and mobile pages
- Action dropdown for product edit and delete

## Main Pages

- Login page: `auth/login.php`
- Register page: `auth/register.php`
- Dashboard page: `dashboard.php`
- View products page: `products/index.php`
- Add product page: `products/create.php`
- Edit product page: `products/edit.php`
- Delete products page: `products/delete.php`

## Database

The database file is included in the `database` folder:

```text
database/inventory_db.sql
```

An extra copy remains at the project root as `inventory_db.sql` for convenience.
