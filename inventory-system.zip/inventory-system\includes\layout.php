<?php
function render_sidebar()
{
    ?>
    <aside class="sidebar">
        <div class="brand">
            <span class="brand-mark">IS</span>
            <div>
                <h2>Inventory System</h2>
                <p>Stock control panel</p>
            </div>
        </div>
        <nav class="main-nav">
            <a href="/inventory-system/dashboard.php">Dashboard</a>
        </nav>
        <button class="menu-toggle" type="button" onclick="toggleProductMenu()">Products</button>
        <nav id="productSubmenu" class="submenu">
            <a href="/inventory-system/products/index.php">View Products</a>
            <a href="/inventory-system/products/create.php">Add Product</a>
            <a href="/inventory-system/products/delete.php">Delete Products</a>
        </nav>
    </aside>
    <?php
}

function render_topbar()
{
    $name = $_SESSION['user'] ?? 'User';
    ?>
    <header class="topbar">
        <div>
            <p class="topbar-kicker">Welcome back</p>
            <strong>Manage your inventory with confidence.</strong>
        </div>
        <div class="user-menu">
            <button class="user-button" type="button" onclick="toggleUserMenu()">
                <?php echo htmlspecialchars($name); ?>
            </button>
            <div id="userDropdown" class="user-dropdown">
                <a href="/inventory-system/auth/logout.php">Logout</a>
            </div>
        </div>
    </header>
    <?php
}
?>
