<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';
require_once 'includes/layout.php';

$stats = [
    'products' => 0,
    'items' => 0,
    'value' => 0,
    'low_stock' => 0,
];

$summary = $conn->query('SELECT COUNT(*) AS products, COALESCE(SUM(quantity), 0) AS items, COALESCE(SUM(quantity * price), 0) AS value, SUM(CASE WHEN quantity <= 10 THEN 1 ELSE 0 END) AS low_stock FROM products');
if ($summary) {
    $stats = array_merge($stats, $summary->fetch_assoc());
}

$recentProducts = $conn->query('SELECT id, product_name, category, quantity, price FROM products ORDER BY id DESC LIMIT 5');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Inventory System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php render_sidebar(); ?>
        <main class="main-panel">
            <?php render_topbar(); ?>
            <section class="content">
                <div class="page-heading">
                    <div>
                        <p class="eyebrow">Dashboard</p>
                        <h1>Inventory overview</h1>
                    </div>
                    <a class="btn btn-primary" href="products/create.php">Add product</a>
                </div>

                <div class="stats-grid">
                    <article class="stat-card">
                        <span>Total products</span>
                        <strong><?php echo (int) $stats['products']; ?></strong>
                    </article>
                    <article class="stat-card">
                        <span>Items in stock</span>
                        <strong><?php echo (int) $stats['items']; ?></strong>
                    </article>
                    <article class="stat-card">
                        <span>Stock value</span>
                        <strong>$<?php echo number_format((float) $stats['value'], 2); ?></strong>
                    </article>
                    <article class="stat-card warning">
                        <span>Low stock</span>
                        <strong><?php echo (int) $stats['low_stock']; ?></strong>
                    </article>
                </div>

                <div class="section-heading">
                    <div>
                        <p class="eyebrow">Latest activity</p>
                        <h2>Recent products</h2>
                    </div>
                    <a href="products/index.php">View all</a>
                </div>

                <div class="table-wrap">
                    <?php if ($recentProducts && $recentProducts->num_rows > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($product = $recentProducts->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                                        <td><?php echo (int) $product['quantity']; ?></td>
                                        <td>$<?php echo number_format((float) $product['price'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <strong>No products yet.</strong>
                            <p>Add your first product to start tracking stock.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
    <script src="assets/js/script.js"></script>
</body>
</html>
