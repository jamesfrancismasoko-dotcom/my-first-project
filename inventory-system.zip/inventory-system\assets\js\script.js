function toggleProductMenu() {
    var submenu = document.getElementById('productSubmenu');
    if (submenu) {
        submenu.classList.toggle('open');
    }
}

function toggleUserMenu() {
    var dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
}

function toggleActionMenu(id) {
    document.querySelectorAll('.action-dropdown').forEach(function (menu) {
        if (menu.id !== 'actionMenu' + id) {
            menu.classList.remove('open');
        }
    });

    var dropdown = document.getElementById('actionMenu' + id);
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
}

document.addEventListener('click', function (event) {
    if (!event.target.closest('.user-menu')) {
        var userDropdown = document.getElementById('userDropdown');
        if (userDropdown) {
            userDropdown.classList.remove('open');
        }
    }

    if (!event.target.closest('.action-menu')) {
        document.querySelectorAll('.action-dropdown').forEach(function (menu) {
            menu.classList.remove('open');
        });
    }
});
