<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
require_once '../includes/layout.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = trim($_POST['product_name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $quantity = (int) ($_POST['quantity'] ?? 0);
    $price = (float) ($_POST['price'] ?? 0);

    if ($productName === '' || $category === '' || $quantity < 0 || $price < 0) {
        $error = 'Please enter valid product details.';
    } else {
        $stmt = $conn->prepare('INSERT INTO products (product_name, category, quantity, price) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('ssid', $productName, $category, $quantity, $price);

        if ($stmt->execute()) {
            header('Location: index.php');
            exit();
        }

        $error = 'Unable to save product.';
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Inventory System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php render_sidebar(); ?>
        <main class="main-panel">
            <?php render_topbar(); ?>
            <section class="content">
                <div class="page-heading">
                    <div>
                        <p class="eyebrow">Products</p>
                        <h1>Add product</h1>
                    </div>
                    <a class="btn btn-secondary" href="index.php">Back to list</a>
                </div>
                <div class="form-wrap">
                    <?php if ($error !== ''): ?>
                        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <form class="product-form" action="create.php" method="POST">
                        <label for="product_name">Product Name</label>
                        <input type="text" id="product_name" name="product_name" required>

                        <label for="category">Category</label>
                        <input type="text" id="category" name="category" required>

                        <label for="quantity">Quantity</label>
                        <input type="number" id="quantity" name="quantity" min="0" required>

                        <label for="price">Price</label>
                        <input type="number" id="price" name="price" min="0" step="0.01" required>

                        <div class="form-actions">
                            <a class="btn btn-secondary" href="index.php">Cancel</a>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </section>
        </main>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
